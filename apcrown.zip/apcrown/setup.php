<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Token Access</title>


    <style>
a:link, a:visited {
  background-color: #f44336;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: red;
}
</style>
</head>
<body>
<h2>Access Token</h2>


<a href="http://localhost/apcrown/index.php?code=aPrxYXyxzkuBzbgNMYqtg8Tv.ouom8336HR9rTCk1Fzn1tvrp2xOSuI79gNlno75z4ANoaYEzA%3D%3D" target="_blank">Get Token</a>





</body>


</html>
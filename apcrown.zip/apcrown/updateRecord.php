<?php
$fieldsToUpdate = array (
'FirstName' => 'TheBlogReaders.com 1',
'City' => 'BANGALORE',
'Country' => 'INDIA'
);
$sObject1 = new SObject();
$sObject1->fields = $fieldsToUpdate;
$sObject1->type = 'Contact';
$sObject1->Id = $UPDATEID1; // YOU NEED TO MENTION THE UDATE FIELD ID

$response = $loginResult->update(array ($sObject1));
print_r($response);

} 


catch (Exception $e) {
    print_r($loginResult->getLastRequest());
    echo $e->faultstring;
    }
    ?>

<?php
$sObject->fields[‘FirstName’] = ‘Bill’;
$sObject->fields[‘LastName’] = ‘Clinton’;
$upsertResponse = $loginResult->upsert(“Email”, array ($sObject));
?>

<?php
$search = 'FIND {415*} IN PHONE FIELDS '.
'RETURNING CONTACT(ID, PHONE, FIRSTNAME, LASTNAME), '.
'LEAD(ID, PHONE, FIRSTNAME, LASTNAME), '.
'ACCOUNT(ID, PHONE, NAME)';
$searchResult = $loginResult->search($search);
print_r($searchResult);
?>
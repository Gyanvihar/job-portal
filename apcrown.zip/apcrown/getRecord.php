<?php
ini_set("soap.wsdl_cache_enabled", "0");

// PHP Tool Kit class scripts to login to Salesforce Org
require_once ('./includes/Force.com/soapclient/SforcePartnerClient.php');
require_once ('./includes/Force.com/soapclient/SforceHeaderOptions.php');

// Salesforce Login information
$wsdl = 'partner.wsdl.xml';    // PARTNER WSDL FILE PATH
$userName = "abhishek-salesforce-login@gmail.com";
$password = "abhishek91227kkE215jKnevoHvd2sXOd4pL"; // PASSWORD SHOULD BE COMBINATION OF “PASSWORD + SECURITY TOKEN”, if it’s a Developer ORG.

// Process of logging on and getting a salesforce.com session
$client = 'new SforcePartnerClient'();
$client->createConnection($wsdl);
$loginResult = $client->login($userName, $password);

//Then perform to get your Contact records from Your Salesforce ORG
$query = "SELECT Id, FirstName, LastName, Phone from Contact";
$response = $loginResult->query($query);
foreach ($response->records as $record)
{
echo '<tr>
<td>'.$record->Id.'</td>
<td>'.$record->fields->FirstName.'</td>
<td>'.$record->fields->LastName.'</td>
<td>'.$record->fields->Phone.'</td>
</tr>';
}
?>
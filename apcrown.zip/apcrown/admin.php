<!doctype html>
<html class="no-js" lang="zxx">

<head>
  


  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Salesforce Jobs</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="manifest" href="site.webmanifest">
  <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

  <!-- CSS here -->

  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
  <link rel="stylesheet" href="assets/css/flaticon.css">
  <link rel="stylesheet" href="assets/css/price_rangs.css">
  <link rel="stylesheet" href="assets/css/slicknav.css">
  <link rel="stylesheet" href="assets/css/animate.min.css">
  <link rel="stylesheet" href="assets/css/magnific-popup.css">
  <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
  <link rel="stylesheet" href="assets/css/themify-icons.css">
  <link rel="stylesheet" href="assets/css/slick.css">
  <link rel="stylesheet" href="assets/css/nice-select.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


  <style>
    /* body {
  background-color: #EEEEEE;
} */

    .layout-margin-8 {
      margin: 3% 8%;
    }

    .card-img-top-custom {
      width: 50%;
      margin: 0 auto;
    }

    .card-title {
      text-align: center;
    }

    .card-shadow {
      -webkit-box-shadow: 0px 0px 28px 14px rgba(232, 232, 232, 1);
      -moz-box-shadow: 0px 0px 28px 14px rgba(232, 232, 232, 1);
      box-shadow: 0px 0px 28px 14px rgba(232, 232, 232, 1);
    }

    .card-deck {
      display: flex;
      justify-content: space-around;
      flex-flow: row wrap;
      align-items: stretch;
    }

    .card {
      padding: 3% 1.5%;
      border: none;
      max-width: 375px;
      flex-grow: 1;
    }

    @media (min-width: 768px) {
      .form-control {
        width: 500px !important;
        height: 50px;
      }
    }

    .bg-blue {
      background-color: #005EB8;
    }

    table,
    th,
    td {
      border: 1px solid black;
      text-align: center;
      margin-left: 15px;

    }
  </style>
</head>

<body>
  <header>
    <!-- Header Start -->
    <div class="header-area header-transparrent">
      <div class="headder-top header-sticky">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-3 col-md-2">
              <!-- Logo -->
              <div class="logo">
                <a href="index.html"><img src="assets/img/logo/logoAppy.png" alt=""></a>
              </div>
            </div>
            <div class="col-lg-9 col-md-9">
              <div class="menu-wrapper">
                <!-- Main-menu -->
                <div class="main-menu">
                  <nav class="d-none d-lg-block">
                    <ul id="navigation">
                      <li><a href="admin.php"> Admin Page </a></li>
                      <li><a href="index.php"> List of Employer</a></li>
                      <li><a href="employee.html"> List of Professional </a></li>

                      <li><a href="add.php"> Add Employee </a></li>
                      <!-- <li><a href="about.html">About</a></li> -->
                      <!-- <li><a href="#">Page</a>
                                                <ul class="submenu">
                                                    <li><a href="blog.html">Blog</a></li>
                                                    <li><a href="single-blog.html">Blog Details</a></li>
                                                    <li><a href="elements.html">Elements</a></li>
                                                    <li><a href="job_details.html">job Details</a></li>
                                                </ul>
                                            </li> -->
                      <!-- <li><a href="contact.html">Contact</a></li> -->
                    </ul>
                  </nav>
                </div>
                <!-- Header-btn -->
                <!-- <div class="header-btn d-none f-right d-lg-block">
                                    <a href="#" class="btn head-btn1">Register</a>
                                    <a href="#" class="btn head-btn2">Login</a>
                                </div> -->
              </div>
            </div>
            <!-- Mobile Menu -->
            <div class="col-12">
              <div class="mobile_menu d-block d-lg-none"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Header End -->
  </header>
  <div class="our-services ">
    <div class="container ">
      <div class="row">
        <div class="col-lg-12">
          <div class="section-tittle text-center">
            <!-- <span>FEATURED TOURS Packages</span> -->
            <h2>Data to be Displayed </h2>
            <!-- <p>List of Employer</p> -->
          </div>
        </div>
      </div>





      <table class="ml-5">
        <tr>

          <th name="first_name"> FirstName</th>
          <th name="last_name">LastName</th>
          <th name="company">Company</th>
          <th name="jobtype">JobType</th>
          <th name="link">Link</th>
          <th>Display</th>
        </tr>
        <!-- $Lname=$_POST['last_name'];
  $link=$_POST['link'];
  $jobtype=$_POST['jobtype'];
  $company=$_POST['company' -->



        <?php

        // include "fetchdata.php"; 

        // or below

        include "conn.php";
        //$conn=mysqli_connect("localhost","root","","db_sms");


        $sql = " select * from display";
        $res = mysqli_query($conn, $sql);
        //$op='edit';

        if ($res->num_rows > 0) {

          while ($row = $res->fetch_assoc()) {

            echo '
        <form action="index.php" method="post">
        <tr>

      <td>  <input type="text" name="firstname" id="first_name" value= ' . $row['fname'] . '>  </td>
      <td ><input type="text" name="lastname" id="last_name" value= ' . $row['lname'] . '> </td>
      <td> <input type="text" name="comp" id="comp" value=' . $row['company'] . '> </td>
      <td> <input type="text" name="type" id="type" value=' . $row['jobtype'] . '> </td>
      <td > <input type="text" name="linkd" id="linkd" value= ' . $row['link'] . '> </td>
      <td>
      <input class="" type="submit" name="submit"  id="mybutton">
      
      
      
      </td>
    </tr>
    </form>';
            // echo  "<tr><td>".$row['id'].    "<td>".$row['name'].   "<td>".$row['LastName']. 
            //   "<td >"."<a href='update.php?rn=$row[id] & sn=$row[name] & sln=$row[LastName]'> Edit </a> " . "<td>".  "<a href='delete.php?rn=$row[id] & sn=$row[name] & sln=$row[LastName]'  onclick=' return checkdelete()'> Delete </a> " . "</tr>";
          }
        }




        ?>

      </table>
    </div>
  </div>

</body>

</html>





<?php
if (isset($_POST['submit'])) {
  include "conn.php";

  $firstName = $_POST['firstname'];
  $lastName = $_POST['lastname'];
  $link = $_POST['linkd'];
  $jobtype = $_POST['type'];
  $company = $_POST['comp'];


  // Database connection
  $conn = new mysqli('localhost', 'root', '', 'job');
  if ($conn->connect_error) {
    echo "$conn->connect_error";
    die("Connection Failed : " . $conn->connect_error);
  } else {
    $stmt = $conn->prepare("insert into employee(fname,lname,link, jobtype, company) values(?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $firstName, $lastName, $link, $jobtype, $company);
    $execval = $stmt->execute();
    echo $execval;
    echo "Registration successfully...";
    $stmt->close();
    $conn->close();
  }
}

// if(isset($_POST['submit'])){

//   include "conn.php";  
//   $fName=$_POST['firstname'];
//   $lastname=$_POST['lastname'];
//   $linkd=$_POST['linkd'];
//   $jobtype=$_POST['type'];
//   $comp=$_POST['comp'];

//   $insertquery=" INSERT INTO display (fname,lname,link, jobtype, company) VALUES('$fName', '$lastname', '$linkd','$jobtype','$comp') ";

//   $res=mysqli_query($conn,$insertquery);

//   if($res){

//     header("location:index.php");





//   }



// }




?>

















<!-- <a class="btn btn-primary" href="index.php?rn= ' . $row['fname'] . '& sn=' . $row['lname'] . ' & com=' . $row['company']. ' & sln=' . $row['link'] . ' " role="button" name="add" >ADD</a> -->
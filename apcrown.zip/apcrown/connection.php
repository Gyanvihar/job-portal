<?php
define("USERNAME", "abhishek-salesforce-login@gmail.com");
define("PASSWORD", "abhishek9122");
define("SECURITY_TOKEN","7kkE215jKnevoHvd2sXOd4pL");

require_once ('./soapclient/SforcePartnerClient.php');
require_once ('./soapclient/SforceBaseClient.php');

$mySforceConnection ->newSforcePartnerClient();
$mySforceConnection->createConnection("./PartnerWSDL.xml");
$login = $mySforceConnection->login(USERNAME, PASSWORD.SECURITY_TOKEN); //
//$login = $mySforceConnection->login(USERNAME, PASSWORD); //Not required token because added IP address to access salesforce
echo "<pre>";print_r($login);


$userInfo = $mySforceConnection->getUserInfo();
echo "<pre>";print_r($userInfo);

$query = "SELECT Id, FirstName, LastName, Phone from Contact";
$response = $mySforceConnection->query($query);

$table .= "<table border=1>";
$table .= "<tr>
<th>Contact ID </th>
<th>First Name</th>
<th> Last Name </th>
<th>Phone </th>
</tr>";
foreach ($response->records as $record)
{
$table .= '<tr>
<td style="padding:5px">'.$record->Id.'</td>
<td style="padding:5px">'.$record->fields->FirstName.'</td>
<td style="padding:5px">'.$record->fields->LastName.'</td>
<td style="padding:5px">'.$record->fields->Phone.'</td>
</tr>';
}
$table .= "</table>";

echo $table;
?>